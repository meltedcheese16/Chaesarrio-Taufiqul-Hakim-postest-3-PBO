package data;

public class Daun extends Sayuran {
    private String warnaDaun;

    public Daun(String nama, int berat, String tanggal, String grade, String lokasi, String warnaDaun) {
        super(nama, berat, tanggal, grade, lokasi);
        this.warnaDaun = warnaDaun;
    }

    @Override
    public String toString() {
        return super.toString() + " | Daun: " + warnaDaun;
    }
}