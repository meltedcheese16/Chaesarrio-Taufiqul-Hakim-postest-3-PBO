package data;

public interface Gradeable {
    String getGradeInfo();
}
