package data;

public abstract class Sayuran {
    protected String nama;
    protected int berat;
    protected String tanggal;
    protected String grade;
    protected String lokasi;

    public Sayuran(String nama, int berat, String tanggal, String grade, String lokasi) {
        this.nama = nama;
        this.berat = berat;
        this.tanggal = tanggal;
        this.grade = grade;
        this.lokasi = lokasi;
    }

    @Override
    public String toString() {
        return nama + " | " + berat + "kg | " + tanggal + " | " + grade + " | " + lokasi;
    }
}
