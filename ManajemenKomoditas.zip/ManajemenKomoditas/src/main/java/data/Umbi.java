package data;

public class Umbi extends Sayuran {
    private String jenisUmbi;

    public Umbi(String nama, int berat, String tanggal, String grade, String lokasi, String jenisUmbi) {
        super(nama, berat, tanggal, grade, lokasi);
        this.jenisUmbi = jenisUmbi;
    }

    @Override
    public String toString() {
        return super.toString() + " | Umbi: " + jenisUmbi;
    }
}