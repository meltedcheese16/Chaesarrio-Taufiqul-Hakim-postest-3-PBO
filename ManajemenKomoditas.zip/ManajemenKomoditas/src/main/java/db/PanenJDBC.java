package db;

import java.sql.*;

public class PanenJDBC {
    private final String url = "jdbc:mysql://localhost:3306/panen_db?useSSL=false&serverTimezone=UTC";
    private final String user = "root";
    private final String pass = "";

    public void tampilkanData() {
        try (Connection conn = DriverManager.getConnection(url, user, pass);
             Statement stmt = conn.createStatement()) {

            String query = "SELECT * FROM sayuran";
            ResultSet rs = stmt.executeQuery(query);

            System.out.printf("| %-3s | %-13s | %-9s | %-10s | %-5s | %-15s | %-10s |%n",
                    "ID", "Nama", "Berat", "Tanggal", "Grade", "Lokasi", "Tambahan");
            System.out.println("--------------------------------------------------------------------------------");

            while (rs.next()) {
                System.out.printf("| %-3d | %-13s | %-9d | %-10s | %-5s | %-15s | %-10s |%n",
                        rs.getInt("id"),
                        rs.getString("nama"),
                        rs.getInt("berat"),
                        rs.getString("tanggalPanen"),
                        rs.getString("grade"),
                        rs.getString("lokasiLahan"),
                        rs.getString("tambahan"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
