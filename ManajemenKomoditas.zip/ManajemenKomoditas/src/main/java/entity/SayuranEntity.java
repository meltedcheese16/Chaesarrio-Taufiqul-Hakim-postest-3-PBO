package entity;

import jakarta.persistence.*;

@Entity
@Table(name = "sayuran")
public class SayuranEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String nama;
    private int berat;

    @Column(name = "tanggalPanen")
    private String tanggalPanen;

    private String grade;
    private String lokasiLahan;
    private String tambahan; // jenisUmbi / warnaDaun

    // Getter & Setter
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public int getBerat() { return berat; }
    public void setBerat(int berat) { this.berat = berat; }

    public String getTanggalPanen() { return tanggalPanen; }
    public void setTanggalPanen(String tanggalPanen) { this.tanggalPanen = tanggalPanen; }

    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    public String getLokasiLahan() { return lokasiLahan; }
    public void setLokasiLahan(String lokasiLahan) { this.lokasiLahan = lokasiLahan; }

    public String getTambahan() { return tambahan; }
    public void setTambahan(String tambahan) { this.tambahan = tambahan; }
}
