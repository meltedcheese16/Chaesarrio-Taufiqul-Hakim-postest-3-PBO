package main;

import data.*;
import manager.PanenManager;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PanenManager pm = new PanenManager();
        boolean aktif = true;

        while (aktif) {
            System.out.println("\n=== SISTEM PENCATATAN HASIL PANEN ===");
            System.out.println("1. Tambah Sayuran");
            System.out.println("2. Lihat Semua Sayuran");
            System.out.println("3. Update Sayuran");
            System.out.println("4. Hapus Sayuran");
            System.out.println("5. Keluar");
            System.out.print("Pilih menu: ");
            int pilih = scanner.nextInt();
            scanner.nextLine();

            switch (pilih) {
                case 1: 
                    System.out.print("Nama komoditas: ");
                    String nama = scanner.nextLine();
                    System.out.print("Berat (kg): ");
                    int berat = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Tanggal panen (dd-mm-yyyy): ");
                    String tanggal = scanner.nextLine();
                    System.out.print("Grade (A/B/C): ");
                    String grade = scanner.nextLine();
                    System.out.print("Lokasi lahan: ");
                    String lokasi = scanner.nextLine();
                    System.out.print("Jenis sayuran (1=Umbi, 2=Daun): ");
                    int jenis = scanner.nextInt();
                    scanner.nextLine();

                    if (jenis == 1) {
                        System.out.print("Masukkan jenis umbi (contoh: wortel, kentang): ");
                        String jenisUmbi = scanner.nextLine();
                        pm.tambahHasil(new Umbi(nama, berat, tanggal, grade, lokasi, jenisUmbi));
                    } else {
                        System.out.print("Masukkan warna daun (contoh: hijau tua, hijau muda): ");
                        String warnaDaun = scanner.nextLine();
                        pm.tambahHasil(new Daun(nama, berat, tanggal, grade, lokasi, warnaDaun));
                    }
                    break;

                case 2: 
                    pm.tampilkanHasil();
                    break;

                case 3: 
                    pm.tampilkanHasil();
                    System.out.print("Nomor data yang ingin diupdate: ");
                    int idx = scanner.nextInt() - 1;
                    scanner.nextLine();

                    System.out.print("Nama komoditas baru: ");
                    String namaBaru = scanner.nextLine();
                    System.out.print("Berat baru (kg): ");
                    int beratBaru = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Tanggal baru (dd-mm-yyyy): ");
                    String tanggalBaru = scanner.nextLine();
                    System.out.print("Grade baru (A/B/C): ");
                    String gradeBaru = scanner.nextLine();
                    System.out.print("Lokasi baru: ");
                    String lokasiBaru = scanner.nextLine();
                    System.out.print("Jenis sayuran (1=Umbi, 2=Daun): ");
                    int jenisBaru = scanner.nextInt();
                    scanner.nextLine();

                    boolean hasil;
                    if (jenisBaru == 1) {
                        System.out.print("Masukkan jenis umbi baru: ");
                        String jenisUmbiBaru = scanner.nextLine();
                        hasil = pm.updateHasil(idx, new Umbi(namaBaru, beratBaru, tanggalBaru, gradeBaru, lokasiBaru, jenisUmbiBaru));
                    } else {
                        System.out.print("Masukkan warna daun baru: ");
                        String warnaDaunBaru = scanner.nextLine();
                        hasil = pm.updateHasil(idx, new Daun(namaBaru, beratBaru, tanggalBaru, gradeBaru, lokasiBaru, warnaDaunBaru));
                    }

                    if (hasil) System.out.println(">>> Data berhasil diupdate!");
                    else System.out.println("Nomor tidak valid!");
                    break;

                case 4: 
                    pm.tampilkanHasil();
                    System.out.print("Nomor data yang ingin dihapus: ");
                    int idxHapus = scanner.nextInt() - 1;
                    scanner.nextLine();

                    if (pm.hapusHasil(idxHapus)) System.out.println(">>> Data berhasil dihapus!");
                    else System.out.println("Nomor tidak valid!");
                    break;

                case 5: 
                    aktif = false;
                    System.out.println("Program selesai. Terima kasih!");
                    break;

                default: 
                    System.out.println("Pilihan tidak valid.");
                    break;
            }
        }
        scanner.close();
    }
}
