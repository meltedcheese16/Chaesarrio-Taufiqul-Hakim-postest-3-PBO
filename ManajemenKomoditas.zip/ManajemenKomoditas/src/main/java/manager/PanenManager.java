package manager;

import java.util.ArrayList;
import data.Sayuran;

public class PanenManager {
    private ArrayList<Sayuran> listHasil = new ArrayList<>();

    public void tambahHasil(Sayuran s) {
        listHasil.add(s);
    }

    public boolean updateHasil(int index, Sayuran s) {
        if (index >= 0 && index < listHasil.size()) {
            listHasil.set(index, s); // sekarang menerima semua tipe Sayuran
            return true;
        }
        return false;
    }

    public boolean hapusHasil(int index) {
        if (index >= 0 && index < listHasil.size()) {
            listHasil.remove(index);
            return true;
        }
        return false;
    }

    public void tampilkanHasil() {
        if (listHasil.isEmpty()) {
            System.out.println("Data kosong!");
            return;
        }
        int no = 1;
        for (Sayuran s : listHasil) {
            System.out.println(no + ". " + s);
            no++;
        }
    }
}
