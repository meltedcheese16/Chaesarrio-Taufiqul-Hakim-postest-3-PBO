package manager;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class PanenORM {
    private SessionFactory factory;

    public PanenORM() {
        factory = new Configuration().configure("/config/hibernate.xml")
                .buildSessionFactory();
    }

    public SessionFactory getFactory() {
        return factory;
    }
}
